const Discord = require("discord.js");
//This will be pure RNG, when someone uses it, one of (Insert a large number here) quotes will be said, along with the user who said it and when (that will be manually inputed)
exports.run = (client, message, args) => {
  let quote = parseInt(Math.floor((Math.random() * 12) + 1));
  
  //Don't ever start variable names with a capital letter, except for Discord
  //you can do Math.floor() in the same variable
  //put parseInt, just in case the system makes it a string and not an integer
  
  message.delete().catch(O_o=>{});
  
  if(quote == 1) {
    message.channel.send('*"Muddy made me chock on a Mega Nut with his Noot Noot"*\n <@213853657937084416>\n 2018')
    
  }else if(quote == 2) {
    message.channel.send('*"See, I would let you be able to use eval, if you couldnt ban the entire server accidentally. Eval is a dangerous command. It can also wipe out my entire computer hard drive. So Im the only one who can use it."*\n <@400059969946386443>\n 2018')
    
  }else if(quote == 3) {
    message.channel.send('*"Dont worry im a therapist. I have councaled many couple and it end swell"*\n <@269896869692309515>\n 2018')
    
  }else if(quote == 4) {
    message.channel.send('*"Hello Homo Sapiens!  I would like to declare the fact that I, The Muddy of the Mudkips, am currently bored, and would like to share my boredom with a Homo Sapien through the use of vibrating vocal chords in the use of communication, which is then sent through the air into the microphone, vibrating small coils inside of the microphone, which then sends electrical current to my audio interface, which enhances the audio of the vibrating coils which were vibrated from the air which was vibrated from my vocal chords, which sends an electrical current to my computing device, which sends a certain frequency of audio to my router saying, "Attention Router, this Mudkip is attempting to send this audio to a Homo Sapien across the world.  Would you please like to send this audio to them?" in which the router does, and you receive the audio in 1s and 0s which is translated by your Computing Device and is translated into the vibrations that went through the air localized in my area which was vibrated from my vocal chords.  In other words: Does anyone want to Voice chat?"*\n <@105098228097130496>\n 2018')
    
  }else if(quote == 5) {
    message.channel.send('*"Muddy, Ravioli, Suck Me"*\n <@412333350137888771>\n 2018')
    
  }else if(quote == 6) {
    message.channel.send('*"Im perfectly creamy"*\n <@213853657937084416>\n 2018')
    
  }else if(quote == 7) {
    message.channel.send('*"I am a pineapple waffle"*\n <@213853657937084416>\n 2018')
    
  }else if(quote == 8) {
    message.channel.send('*"Mudkip you slut"*\n <@213853657937084416>\n 2018')
  
  }else if (quote == 9) {
      message.channel.send('*"My excuse is that all along I thought it was cummies."*\n <@412333350137888771>\n 2018')
    
  }else if (quote == 10){
    message.channel.send('*"I`VE CUMMED ENOUGH DONCHA THINK!"*\n <@213853657937084416>\n 2018')
    
  }else if (quote == 11){
    message.channel.send('*"I must say this is a genius command that wins the best oscars in the history of the planet Earth. Steven Hawkings corpse is gonna congradulate you for you accomplisment."*\n <@272814056966979586>\n 2018')
  
  }else if (quote == 12){
    message.channel.send('*"I AM NOT A COMPLETE WHORE!"*\n <@213853657937084416>\n 2018')
    
  }else
    return message.channel.send('Quote system failed, have a good day.')
}