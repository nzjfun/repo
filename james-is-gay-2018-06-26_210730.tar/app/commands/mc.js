const Discord = require("discord.js");

exports.run = (client, message, args) => {
  
  let dmBoyo = message.mentions.members.first();
  
  args.shift();
  
  message.delete().catch(O_o=>{}); 
  
  message.author.send("Why did you do this?  You have now triggered a set of events that lead to you being...");
  
  let demise = parseInt(Math.floor((Math.random() * 5) + 1));
  
  if(demise == 1){
    message.author.send('gay. Now you might be saying, "Ok, how exactly is that bad?" In 2020, being gay will result in torture, followed by a long and painful death. Exactly how they will torture you will depend on who is torturing you at the time, but it will always be extremly unpleasant, like watching straight sex for 240 hours straight without any breaks for any reason. So yeah!')
  }else if(demise == 2){
    message.author.send('a perma squeaker. Now you might be saying, "Ok, why exactly is that bad? Just keep my microphone off." In 2020, being a squeaker while playing a game, microphone on or off, will result in any player you meet being allowed to say anything they want about you and having the ablility to force you to do anything IRL until you leave the game + 24 hours. So yeah!')
  }else if(demise == 3){
    message.author.send('dead. Now you might be saying, "Ok, how is that bad? I want to die afterall." In 2020, you dont die from a gun shot, or jumping off a building. You die from too much sex. Specifically, to much gang rape. More specifically, gang rape in the asshole. Now, you dont die from the raping alone, you die from the blood loss from the raping in the ass. So yeah!')
  }else if(demise == 4){
    message.author.send('black. Now you might be saying, "Ok, how is that bad?" Take a guess. In 2020, all blacks, male, female, or child, are taken back into slavery, and it is just like in the 1800s, when slavery was legal. You get wipped, smacked, tortured, raped, and eventually killed. So if you did not want to die, you are out of luck my friend. So yeah!')
  }else if(demise == 5){
    message.author.send('in the 1800s. Now you might be saying, "OH NO! I HAVE NO CELL SIGNAL BECAUSE IT WAS NOT INVENTED YET!" or, "Wait, is this secretly good?" Well, besides not having any modern technology, it is VERY bad! You get disease after disease, you are near the war of 1812, you need to actually build a house, and you need to get food by HUNTING! So yeah!')
  }
}

//i must say this is a genius command that wins the best oscars in the history of the planet earth steven hawking's corpse is gonna congradulate you for you accomplisment -stjames221

