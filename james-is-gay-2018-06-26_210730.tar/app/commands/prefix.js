const Discord = require("discord.js");
const fs = require("fs");

exports.run = (client, message, args) => {
  const config = require("../config.json");
  let newPrefix = message.content.split(" ").slice(1, 2)[0];
  if (!newPrefix)
    return message.channel.send("Add a prefix");
  
  config.prefix = newPrefix

    fs.writeFile("./config.json", JSON.stringify(config), (err) => console.error);
    message.channel.send(`prefix has now been changed to ${config.prefix}`)
}