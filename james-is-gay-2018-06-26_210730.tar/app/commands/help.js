const Discord = require("discord.js");

exports.run = (client, message, args) => {
  
  let dmBoyo = message.mentions.members.first();
  
  args.shift();
  
  message.delete().catch(O_o=>{});
  
  message.author.send("All of the commands start with 'Mc'\n Ping: Gives you your ping and the AI's ping.\n Quote: Choses one of a select amount of quotes, sends it, along with who sent it\n Mc: Why would you even use this?  It does nothing.");
}