const Discord = require("discord.js");

exports.run = (client, message, args) => {
  message.channel.send(`Pong! Latency is ${Date.now() - message.createdTimestamp}ms. API Latency is ${Math.round(client.ping)}ms`);
}